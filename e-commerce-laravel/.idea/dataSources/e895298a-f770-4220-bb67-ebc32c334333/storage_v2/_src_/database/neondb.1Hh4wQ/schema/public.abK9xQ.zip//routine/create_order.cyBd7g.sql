create function create_order(p_profile_id uuid, p_items jsonb) returns uuid
    language plpgsql
as
$$
DECLARE
    v_order_id UUID := gen_random_uuid();
    v_total NUMERIC := 0;
    v_product_id UUID;
    v_quantity INT;
    v_price NUMERIC;
    v_stock INT;
BEGIN
    -- 1. Insert order
    INSERT INTO orders (id, profile_id, total_price, status, created_at, updated_at)
    VALUES (v_order_id, p_profile_id, 0, 'PENDING', NOW(), NOW());

    -- 2. Loop qua items
    FOR v_product_id, v_quantity IN
        SELECT (item->>'product_id')::uuid, (item->>'quantity')::int
        FROM jsonb_array_elements(p_items) AS item
        LOOP
            -- check tồn kho
            SELECT stock, price INTO v_stock, v_price
            FROM products
            WHERE id = v_product_id
                FOR UPDATE;

            IF v_stock < v_quantity THEN
                RAISE EXCEPTION 'Product % is out of stock. Required %, available %',
                    v_product_id, v_quantity, v_stock;
            END IF;

            -- insert order detail
            INSERT INTO order_details (id, order_id, product_id, quantity, price, created_at, updated_at)
            VALUES (gen_random_uuid(), v_order_id, v_product_id, v_quantity, v_price * v_quantity, NOW(), NOW());

            -- trừ stock
            UPDATE products
            SET stock = stock - v_quantity,
                updated_at = NOW()
            WHERE id = v_product_id;

            v_total := v_total + (v_price * v_quantity);
        END LOOP;

    -- 3. update tổng tiền
    UPDATE orders
    SET total_price = v_total,
        updated_at = NOW()
    WHERE id = v_order_id;

    RETURN v_order_id;
END;
$$;

alter function create_order(uuid, jsonb) owner to neondb_owner;

